var http = require('http'),
    fs = require('fs'),
    ccav = require('./ccavutil.js'),
    qs = require('querystring');

exports.postReq = function(request,response){
    var body = '',
	workingKey = '811D1B95D9A8C5F70205F87481FF4C6A',	
	accessCode = 'AVSV38KL32AN58VSNA',		
	encRequest = '',
	formbody = '';
				
    request.on('data', function (data) {
	body += data;
	encRequest = ccav.encrypt(body,workingKey); 
	formbody = '<form id="nonseamless" method="post" name="redirect" action="https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction">' +
                   '<input type="hidden" id="encRequest" name="encRequest" value="' + encRequest + '">' +
                   '<input type="hidden" name="access_code" id="access_code" value="' + accessCode + '">' +
                   '</form>' +
                   '<script language="javascript">document.redirect.submit();</script>';
    });

 
				
    request.on('end', function () {
  


        response.writeHeader(200, {"Content-Type": "text/html"});
	response.write(formbody);
	response.end();
    });
   return; 
};
