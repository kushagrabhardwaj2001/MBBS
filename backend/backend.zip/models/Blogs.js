// const mongoose=require('mongoose')
// const BlogSchema = new mongoose.Schema({

//     heading:String,
//     description:String,
//     date : String,
//     image1:String

    
//   }, { collection: 'Blogs' });
  
//   module.exports = mongoose.model('Blogs', BlogSchema);
  