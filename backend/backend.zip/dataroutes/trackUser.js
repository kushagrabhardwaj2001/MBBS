const express = require("express");
const cookieParser = require("cookie-parser");
const mongoose = require("mongoose");

const router = express();
router.use(cookieParser());
// Define Visit schema
const VisitSchema = new mongoose.Schema({
  ip: String,
  timestamp: { type: Date, default: Date.now }
});

const Visit = mongoose.model('Visit', VisitSchema);

// Define Count schema
const CountSchema = new mongoose.Schema({
  totalCount: { type: Number, default: 0 },
  todayCount: { type: Number, default: 0 },
  lastUpdated: { type: Date, default: Date.now }
});

const Count = mongoose.model('Count', CountSchema);

// Increment the count
const incrementCount = async () => {
  const count = await Count.findOne();
  if (count) {
    count.totalCount += 1;
    count.todayCount += 1;
    count.lastUpdated = new Date();
    await count.save();
  } else {
    await Count.create({ totalCount: 1, todayCount: 1 });
  }
};

// API endpoint to track visits
router.get('/count', async (req, res) => {
  const userIp = req.ip; // Get user's IP address
  const currentTime = new Date();

  // Check if there is a visit record for the user within the past 24 hours
  const lastVisit = await Visit.findOne({
    ip: userIp,
    timestamp: { $gte: new Date(currentTime - 24 * 60 * 60 * 1000) }
  });

  if (!lastVisit) {
    // If no visit record found, increment visit count and create new record
    await Visit.create({ ip: userIp });
    await incrementCount();
  }

  // Get the total visit count and today's visit count
  const count = await Count.findOne();
  const totalVisits = count ? count.totalCount : 0;
  const todayVisits = count ? count.todayCount : 0;

  res.json({ totalVisits, todayVisits });
});


// Define Visit schema
// const VisitSchema = new mongoose.Schema({
//   ip: String,
//   timestamp: { type: Date, default: Date.now },
// });

// const Visit = mongoose.model("Visit", VisitSchema);

// // API endpoint to track visits
// router.get("/count", async (req, res) => {
//   const userIp = req.ip; // Get user's IP address
//   const currentTime = new Date();

//   // Check if there is a visit record for the user within the past 24 hours
//   const lastVisit = await Visit.findOne({
//     ip: userIp,
//     timestamp: { $gte: new Date(currentTime - 24 * 60 * 60 * 1000) },
//   });

//   if (!lastVisit) {
//     // If no visit record found, increment visit count and create new record
//     await Visit.create({ ip: userIp });
//   }

//   // Count total visits
//   const totalVisits = await Visit.countDocuments();

//   res.json({ totalVisits });
// });

// const visitSchema = new mongoose.Schema({
//   visitCount: { type: Number, default: 0 },
// });
// const Visit = mongoose.model('Visit', visitSchema);

// // Middleware to track user visits and increment count
// router.use(async (req, res, next) => {
//   // Increment the count for every incoming request
//   await Visit.findOneAndUpdate({}, { $inc: { visitCount: 1 } }, { upsert: true });
//   next();
// });

// router.get('/count', async (req, res) => {
//   const visit = await Visit.findOne();
//   const count = visit ? visit.visitCount : 0;
//   res.send(`Total visits: ${count}`);
// });
module.exports = router;
// Start the server

// // routes/userRoute.js
// const express = require('express');
// const router = express.Router();
// const TrackUser = require('../models/trackNewUser');
// const uuid = require('uuid');

// // GET route to retrieve user information
// router.get('/info', async (req, res) => {
//   let userId = req.cookies.userId;
//   let isNewUser = false;

//   // Check if user is new or returning
//   if (!userId) {
//     userId = uuid.v4();
//     isNewUser = true;
//     res.cookie('userId', userId, { maxAge: 900000, httpOnly: true });
//   }

//   const ipAddress = req.ip;

//   try {
//     // Save user info to database
//     await TrackUser.create({ userId, ipAddress });

//     res.send(`Your unique identifier is: ${userId}<br/>Your IP address is: ${ipAddress}<br/>You are ${isNewUser ? 'a new user' : 'a returning user'}`);
//   } catch (err) {
//     console.error(err);
//     res.status(500).send('Internal Server Error');
//   }
// });

// // POST route to track users
// router.post('/track', async (req, res) => {
//   const { userId } = req.body;
//   let isNewUser = false;

//   // Check if userId is provided
//   if (!userId) {
//     return res.status(400).send('userId is required');
//   }

//   // Check if user with provided userId exists
//   let user = await TrackUser.findOne({ userId });

//   // If user doesn't exist, it's a new user
//   if (!user) {
//     isNewUser = true;
//     const ipAddress = req.ip;
//     try {
//       // Create new user entry
//       await TrackUser.create({ userId, ipAddress });
//       res.send(`User with userId ${userId} has been tracked as a new user.`);
//     } catch (err) {
//       console.error(err);
//       res.status(500).send('Internal Server Error');
//     }
//   } else {
//     res.send(`User with userId ${userId} is a returning user.`);
//   }
// });

// module.exports = router;

// const express = require('express');
// const cookieParser = require('cookie-parser');
// const mongoose = require('mongoose');

// const router = express.Router();
// router.use(cookieParser());

// // Connect to MongoDB

// // Define a schema for storing user visits
// const visitSchema = new mongoose.Schema({
//   userId: String,
//   lastVisit: { type: Date, default: Date.now },
// });
// const Visit = mongoose.model('Visit', visitSchema);

// // Middleware to track user visits
// router.use(async (req, res, next) => {
//   const userId = req.cookies.userId;
//   console.log('userId:', userId)
//   const lastVisit = await Visit.findOne({ userId });

//   if (lastVisit && (Date.now() - lastVisit.lastVisit.getTime()) < 24 * 60 * 60 * 1000) {
//     // If the user has visited in the last 24 hours, do not increment the count
//     console.log('User visited within the last 24 hours');
//   } else {
//     // If the user has not visited in the last 24 hours, increment the count
//     console.log('User visited after more than 24 hours');
//     res.cookie('userId', userId || Math.random().toString(36).substr(2, 9), { maxAge: 24 * 60 * 60 * 1000 }); // Set cookie to expire in 24 hours

//     if (userId) {
//       console.log('userId:', userId)
//       await Visit.findOneAndUpdate({ userId }, { lastVisit: Date.now() });
//     } else {
//       await Visit.create({ userId: req.cookies.userId });
//     }
//   }

//   next();
// });

// // Define a route to get the visit count
// router.get('/count', async (req, res) => {
//   const count = await Visit.countDocuments({});
//   res.send(`Total visits: ${count}`);
// });

// module.exports = router;

// const express = require('express');
// const useragent = require('express-useragent');
// const cookieParser = require('cookie-parser');

// const router = express();
// router.use(useragent.express());
// router.use(cookieParser());

// // Define a route to generate and return a unique identifier
// router.get('/unique-id', (req, res) => {
//   let uniqueId;

//   // Check if the user has a unique identifier stored in a cookie
//   if (req.cookies.uniqueId) {
//     uniqueId = req.cookies.uniqueId;
//   } else {
//     // Generate a new unique identifier if not found
//     uniqueId = generateUniqueId();
//     // Set the unique identifier in a cookie
//     res.cookie('uniqueId', uniqueId, { maxAge: 31536000000 }); // 1 year expiry
//   }

//   res.send(`Your unique ID is: ${uniqueId}`);
// });

// // Helper function to generate a unique identifier
// function generateUniqueId() {
//   // You can use any method to generate a unique ID here
//   return Math.random().toString(36).substr(2, 9);
// }

// router.post('/track', async (req, res) => {
//   const { userId } = req.body;

//   // Check if userId is provided
//   if (!userId) {
//     return res.status(400).send('userId is required');
//   }

//   try {
//     // Check if user with provided userId exists
//     let user = await TrackUser.findOne({ userId });

//     // If user exists, send a message indicating the user is already registered
//     if (user) {
//       return res.send(`User with userId ${userId} is already registered.`);
//     }

//     // If user doesn't exist, create a new user entry
//     const ipAddress = req.ip;
//     await TrackUser.create({ userId, ipAddress });
//     return res.send(`${userId}`);
//   } catch (err) {
//     console.error(err);
//     return res.status(500).send('Internal Server Error');
//   }
// });

// module.exports = router;

// // const express = require('express');
// // const router = express.Router();
// // const TrackUser = require('../models/trackNewUser');
// // const uuid = require('uuid');

// // router.get('/info', async (req, res) => {
// //   let userId = req.cookies.userId;
// //   let isNewUser = false;

// //   // Check if user is new or returning
// //   if (!userId) {
// //     userId = uuid.v4();
// //     isNewUser = true;
// //     res.cookie('userId', userId, { maxAge: 900000, httpOnly: true });
// //   }

// //   const ipAddress = req.ip;

// //   try {
// //     // Save user info to database
// //     await TrackUser.create({ userId, ipAddress });

// //     res.send(`Your unique identifier is: ${userId}<br/>Your IP address is: ${ipAddress}<br/>You are ${isNewUser ? 'a new user' : 'a returning user'}`);
// //   } catch (err) {
// //     console.error(err);
// //     res.status(500).send('Internal Server Error');
// //   }
// // });
// // router.post('/track', async (req, res) => {
// //   const { userId } = req.body;
// //   let isNewUser = false;

// //   // Check if userId is provided
// //   if (!userId) {
// //     return res.status(400).send('userId is required');
// //   }

// //   // Check if user with provided userId exists
// //   let user = await TrackUser.findOne({ userId });

// //   // If user doesn't exist, it's a new user
// //   if (!user) {
// //     isNewUser = true;
// //     const { ipAddress } = req.ip;
// //     try {
// //       // Create new user entry
// //       await TrackUser.create({ userId, ipAddress });
// //       res.send(`User with userId ${userId} has been tracked as a new user.`);
// //     } catch (err) {
// //       console.error(err);
// //       res.status(500).send('Internal Server Error');
// //     }
// //   } else {
// //     res.send(`User with userId ${userId} is a returning user.`);
// //   }
// // });

// // module.exports = router;
